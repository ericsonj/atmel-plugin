/* 
 * File:   main.cpp
 * Author: ejoseph
 *
 * Created on August 11, 2016, 7:56 PM
 */
#include <avr/io.h>

int main(void) {
    
    while (1) {
        
    }
}